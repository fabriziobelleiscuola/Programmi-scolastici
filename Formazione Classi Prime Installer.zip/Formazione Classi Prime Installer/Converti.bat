@echo off
for %%f in (*.bin) do ren "%%f" "%%~nf.exe"
rem echo Conversione completata
rem pause
