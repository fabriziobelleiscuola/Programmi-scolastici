@echo off
for %%f in (*.ex_) do ren "%%f" "%%~nf.exe"
echo Conversione completata
pause
